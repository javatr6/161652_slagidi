package org.cap.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;



@Table(name="routemap")
@Entity
public class RouteMapBean {
	@Id
	
	private int routeId;
	@OneToMany(mappedBy="route",targetEntity=TransactionBean.class,cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	private List<TransactionBean> transactions=new ArrayList<>();
	@OneToOne
	@JoinColumn(name="Fk")
	private BusBean bus;
	
	private String routePath;
	private int occupiedSeats;
	private int totalSeats;
	private String busNo;
	private String busDriver;
	private int totalkm;
	public RouteMapBean() {
		super();
	}
	
	
	public RouteMapBean(int routeId,BusBean bus, String routePath, int occupiedSeats,
			int totalSeats, String busNo, String busDriver, int totalkm) {
		super();
		this.routeId = routeId;
		
		this.bus = bus;
		this.routePath = routePath;
		this.occupiedSeats = occupiedSeats;
		this.totalSeats = totalSeats;
		this.busNo = busNo;
		this.busDriver = busDriver;
		this.totalkm = totalkm;
	}


	public RouteMapBean(String routepath, int occseats, int totalseats, String busno, String busdriver, int totalkm) {
		super();
		this.routePath = routepath;
		this.occupiedSeats = occseats;
		this.totalSeats = totalseats;
		this.busNo = busno;
		this.busDriver = busdriver;
		this.totalkm = totalkm;
	}
	

	public RouteMapBean(int routeid, String routepath, int occseats, int totalseats, String busno, String busdriver,
			int totalkm) {
		super();
		this.routeId = routeid;
		this.routePath = routepath;
		this.occupiedSeats = occseats;
		this.totalSeats = totalseats;
		this.busNo = busno;
		this.busDriver = busdriver;
		this.totalkm = totalkm;
	}

	public int getRouteid() {
		return routeId;
	}
	
	public void setRouteid(int routeid) {
		this.routeId = routeid;
	}
	
	public String getRoutepath() {
		return routePath;
	}
	
	public void setRoutepath(String routepath) {
		this.routePath = routepath;
	}
	
	public int getOccseats() {
		return occupiedSeats;
	}
	
	public void setOccseats(int occseats) {
		this.occupiedSeats = occseats;
	}
	
	public int getTotalseats() {
		return totalSeats;
	}
	
	public void setTotalseats(int totalseats) {
		this.totalSeats = totalseats;
	}
	
	public String getBusno() {
		return busNo;
	}
	
	public void setBusno(String busno) {
		this.busNo = busno;
	}
	
	public String getBusdriver() {
		return busDriver;
	}
	
	public void setBusdriver(String busdriver) {
		this.busDriver = busdriver;
	}
	
	public int getTotalkm() {
		return totalkm;
	}
	
	public void setTotalkm(int totalkm) {
		this.totalkm = totalkm;
	}
	
	@Override
	public String toString() {
		return "RouteMapBean [routeId=" + routeId + ", routePath=" + routePath + ", occupiedSeats=" + occupiedSeats
				+ ", totalSeats=" + totalSeats + ", busno=" + busNo + ", busDriver=" + busDriver + ", totalkm="
				+ totalkm + "]";
	}
	

}
