package org.cap.bean;



import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Table(name="buspassrequest")
@Entity
public class BusBean {
	@Id
	@GeneratedValue
	private Integer requestId;
	private String employeeId;
	private String firstName;
	private String lastName;
	private String gender;
	private String address;
	private LocalDate dateofjoining;
	private String emailId;
	private String location;
	private String pickupLoc;
	private String designation;
	private LocalTime pickupTime;
	
	private String status="Pending";
	@OneToOne
	@JoinColumn
	private RouteMapBean route;
	
	
	public BusBean() {
		super();
	}
	
	
	
	
	public BusBean(String employee_id, String firstName, String lastName, String gender, String address,
			LocalDate dofjoining, String emailId, String location, String pickupLocation, String designation,
			LocalTime pickupTime, String status) {
		super();
		this.employeeId = employee_id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.address = address;
		this.dateofjoining = dofjoining;
		this.emailId = emailId;
		this.location = location;
		this.pickupLoc = pickupLocation;
		this.designation = designation;
		this.pickupTime = pickupTime;
		this.status = status;
	}




	public BusBean(String employeeId, String firstName, String lastName, String gender, String address,
			LocalDate dateofjoining, String emailId, String location, String pickupLoc, String designation,
			LocalTime pickupTime, String status, Integer requestId) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.address = address;
		this.dateofjoining = dateofjoining;
		this.emailId = emailId;
		this.location = location;
		this.pickupLoc = pickupLoc;
		this.designation = designation;
		this.pickupTime = pickupTime;
		this.status = status;
		this.requestId = requestId;
	}



	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getEmployee_id() {
		return employeeId;
	}
	
	public void setEmployee_id(String employee_id) {
		this.employeeId = employee_id;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public String getGender() {
		return gender;
	}
	
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}
	
	public LocalDate getDofjoining() {
		return dateofjoining;
	}
	
	public void setDofjoining(LocalDate dofjoining) {
		this.dateofjoining = dofjoining;
	}
	
	public String getEmailId() {
		return emailId;
	}
	
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	public String getLocation() {
		return location;
	}
	
	public void setLocation(String location) {
		this.location = location;
	}
	
	public String getPickupLocation() {
		return pickupLoc;
	}
	
	public void setPickupLocation(String pickupLocation) {
		this.pickupLoc = pickupLocation;
	}
	
	public LocalTime getPickupTime() {
	return pickupTime;
	}
	
	public void setPickupTime(LocalTime pickupTime) {
		this.pickupTime = pickupTime;
	}
	
	public Integer getRequestId() {
		return requestId;
	}
	
	public void setRequestId(Integer requestId) {
		this.requestId = requestId;
	}

	public RouteMapBean getRoute() {
		return route;
	}

	public void setRoute(RouteMapBean route) {
		this.route = route;
	}

	@Override
	public String toString() {
		return "BusBean [employeeId=" + employeeId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", gender=" + gender + ", address=" + address + ", dateofjoining=" + dateofjoining + ", emailId=" + emailId
				+ ", location=" + location + ", pickupLoc=" + pickupLoc + ", designation=" + designation
				+ ", pickupTime=" + pickupTime + ", status=" + status + ", requestId=" + requestId + "]";
	}

}
