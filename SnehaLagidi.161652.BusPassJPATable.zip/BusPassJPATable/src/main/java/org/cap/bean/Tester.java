package org.cap.bean;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;



public class Tester {

	public static void main(String[] args) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		BusBean bus=new BusBean("4528_FS","Tom","Jerry","Male","Chennai",
				LocalDate.of(2016, 11,12),"tom345@gmail.com","Chennai SIPCOT","Chennai MIPL","Tambaram",
				LocalTime.of(9,30),"Pending");
		
		LoginBean login=new LoginBean("Ninja","Ninja");
		
		RouteMapBean route=new RouteMapBean(03,bus,"ChennaiMIPL,Tambaram",12,45,"AP7456","Raju",48);
		
		RouteMapBean route1= new RouteMapBean(06,bus,"ChennaiMIPL,Tambaram",5,
			60,"AP5786","Ram",30);
		bus.setRoute(route1);
		TransactionBean transactions=new TransactionBean(route,"4528_FS", LocalDate.of(2018,10,15),45.00,6000);
		entityManager.persist(bus);
		entityManager.persist(login);
		entityManager.persist(route);
		entityManager.persist(route1);
		entityManager.persist(transactions);
		transaction.commit();
		entityManager.close();

	}

}
