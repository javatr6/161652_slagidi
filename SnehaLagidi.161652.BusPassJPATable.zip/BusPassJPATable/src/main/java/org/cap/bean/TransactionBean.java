package org.cap.bean;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import javax.persistence.Table;
@Table(name="transaction")
@Entity
public class TransactionBean {
	@Id
	@GeneratedValue
	private Integer transactionId;

	@ManyToOne
	@JoinColumn(name="Route_Id")
	private RouteMapBean route;
	

	
	private String empId;
	private LocalDate transactionDate;
	private Double totalkm;
	private Integer monthlyFare;
	
	
	public TransactionBean() {
		super();
	}
	public TransactionBean(RouteMapBean route,String empId,
			LocalDate transactionDate, Double totalkm, Integer monthlyFare) {
		super();
	
		this.route = route;
	
		this.empId = empId;
		this.transactionDate = transactionDate;
		this.totalkm = totalkm;
		this.monthlyFare = monthlyFare;
	}


	public TransactionBean(String emp_id, LocalDate transaction_date, Double total_km,
			Integer monthly_fare) {
		super();
		
		this.empId = emp_id;
		this.transactionDate = transaction_date;
		this.totalkm = total_km;
		this.monthlyFare = monthly_fare;
	}
	
	
	public TransactionBean(Integer transaction_id,String emp_id, LocalDate transaction_date,
			Double total_km, Integer monthly_fare) {
		super();
		this.transactionId = transaction_id;
	
		this.empId = emp_id;
		this.transactionDate = transaction_date;
		this.totalkm = total_km;
		this.monthlyFare = monthly_fare;
	}


	public Integer getTransaction_id() {
		return transactionId;
	}


	public void setTransaction_id(Integer transaction_id) {
		this.transactionId = transaction_id;
	}




	public String getEmp_id() {
		return empId;
	}


	public void setEmp_id(String emp_id) {
		this.empId = emp_id;
	}


	public LocalDate getTransaction_date() {
		return transactionDate;
	}


	public void setTransaction_date(LocalDate transaction_date) {
		this.transactionDate = transaction_date;
	}


	public Double getTotal_km() {
		return totalkm;
	}


	public void setTotal_km(Double total_km) {
		this.totalkm = total_km;
	}


	public Integer getMonthly_fare() {
		return monthlyFare;
	}


	public void setMonthly_fare(Integer monthly_fare) {
		this.monthlyFare = monthly_fare;
	}
	@Override
	public String toString() {
		return "TransactionBean [transactionId=" + transactionId + ", route=" + route + ", empId=" + empId
				+ ", transactionDate=" + transactionDate + ", totalkm=" + totalkm + ", monthlyFare=" + monthlyFare
				+ "]";
	}


	
	

}
