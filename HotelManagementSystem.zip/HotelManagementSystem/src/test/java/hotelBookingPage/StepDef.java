package hotelBookingPage;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import bean.HotelbookingPageBean;
import bean.SuccessBean;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	private WebDriver driver;
	private HotelbookingPageBean hotelBookingPageBean;
	private SuccessBean successBean;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\\\Users\\\\slagidi\\\\Downloads\\\\chromedriver\\\\chromedriver.exe");
		driver=new ChromeDriver();
		hotelBookingPageBean=new HotelbookingPageBean(driver);
		successBean = new SuccessBean(driver);
	}

	@Given("^open Hotel Booking page$")
	public void open_Hotel_Booking_page() throws Throwable {
		driver.get("file:///C:/Users/slagidi/Downloads/HotelManagementSystem/src/main/webapp/pages/hotelbooking.html");
		assertEquals("Hotel Booking Form",hotelBookingPageBean.getPageHeading());
	}

	@Given("^Personel and payment details$")
	public void personel_and_payment_details() throws Throwable {
	    hotelBookingPageBean.setFirstName("Tom");
	    hotelBookingPageBean.setLastName("Jerry");
	    hotelBookingPageBean.setEmail("tom@cap.com");
	    hotelBookingPageBean.setPhone("8048878154");
	    hotelBookingPageBean.setAddress("Tanuku");
	    hotelBookingPageBean.setCity("Hyderabad");
	    hotelBookingPageBean.setState("Telangana");
	    hotelBookingPageBean.setNumberOfGuestsstaying("5");
	    hotelBookingPageBean.setCardHolderName("Tom");
	    hotelBookingPageBean.setDebitCardNumber("24894515375845615");
	    hotelBookingPageBean.setCvv("255");
	    hotelBookingPageBean.setExpireMonth("10");
	    hotelBookingPageBean.setExpireYear("2019");
	    Thread.sleep(1000);
	}

	@When("^Personel And payment details are not empty$")
	public void personel_And_payment_details_are_not_empty() throws Throwable {
	   hotelBookingPageBean.onSubmit_navigate_to_successPage();
	   Thread.sleep(1000);
	}

	@Then("^navigate to success page$")
	public void navigate_to_success_page() throws Throwable {
		driver.navigate().to("file:///C:/Users/slagidi/Downloads/HotelManagementSystem/src/main/webapp/pages/success.html");
		assertEquals("Booking Completed!",successBean.getMessage());
	}

	@Given("^Personel and payment details are null$")
	public void personel_and_payment_details_are_null() throws Throwable {
		driver.findElement(By.name("txtFN")).sendKeys("");
	}

	@When("^Personel And payment details are empty$")
	public void personel_And_payment_details_are_empty() throws Throwable {
		hotelBookingPageBean.onSubmit_navigate_to_successPage();
		   Thread.sleep(1000);
	}

	@Then("^show alert messages$")
	public void show_alert_messages() throws Throwable {
		String msg = driver.switchTo().alert().getText();
		assertEquals("Please fill the First Name",msg);
	}
	@After
	public void tearDown() {
		driver.quit();
	}
}
