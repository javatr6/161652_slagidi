package org.control.many;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Delegate {
	
	private int DelegateId;
	@Id
	private String delegateName;
	private LocalDate joinDate;
		
	@ManyToMany
	@JoinTable(name="event_delegate",
	joinColumns= {@JoinColumn(name="delegate")},
	inverseJoinColumns= {@JoinColumn(name="event")})
	
	private List<Event> event=new ArrayList<>();

	public Delegate() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Delegate(int delegateId, String delegateName) {
		super();
		DelegateId = delegateId;
		this.delegateName = delegateName;
	}

	public int getDelegateId() {
		return DelegateId;
	}

	public void setDelegateId(int delegateId) {
		DelegateId = delegateId;
	}

	public String getDelegateName() {
		return delegateName;
	}

	public void setDelegateName(String delegateName) {
		this.delegateName = delegateName;
	}

	public List<Event> getEvent() {
		return event;
	}

	public void setEvent(List<Event> event) {
		this.event = event;
	}

	
	public LocalDate getJoinDate() {
		return joinDate;
	}

	public void setJoinDate(LocalDate joinDate) {
		this.joinDate = joinDate;
	}

	@Override
	public String toString() {
		return "Delegate [DelegateId=" + DelegateId + ", delegateName=" + delegateName + ", event=" + event + "]";
	}
	
	
}
