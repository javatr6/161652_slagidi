package org.control.many;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Event {

	@Id
	private int eventId;
	private String eventName;
	
	@ManyToMany
	@JoinTable(name="event_delegate",
	joinColumns= {@JoinColumn(name="event")},
	inverseJoinColumns= {@JoinColumn(name="delegate")})
	
	private List<Delegate> delegate=new ArrayList<>();

	public Event() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Event(int eventId, String eventName, List<Delegate> delegate) {
		super();
		this.eventId = eventId;
		this.eventName = eventName;
		this.delegate = delegate;
	}

	public int getEventId() {
		return eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public List<Delegate> getDelegate() {
		return delegate;
	}

	public void setDelegate(List<Delegate> delegate) {
		this.delegate = delegate;
	}

	@Override
	public String toString() {
		return "Event [eventId=" + eventId + ", eventName=" + eventName + ", delegate=" + delegate + "]";
	}
	
	
}
