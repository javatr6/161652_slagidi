package org.control.employee;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Employee {

		@Id
		private int employeeId;
		private String empolyeeName;
		private LocalDate dateOfJoin;
		
		@ManyToOne
		@JoinColumn(name="companyFk")
		private Company company;

		public Employee() {
			super();
			// TODO Auto-generated constructor stub
		}

		public Employee(int employeeId, String empolyeeName) {
			super();
			this.employeeId = employeeId;
			this.empolyeeName = empolyeeName;
		}

		public int getEmployeeId() {
			return employeeId;
		}

		public void setEmployeeId(int employeeId) {
			this.employeeId = employeeId;
		}

		public String getEmpolyeeName() {
			return empolyeeName;
		}

		public void setEmpolyeeName(String empolyeeName) {
			this.empolyeeName = empolyeeName;
		}

		public Company getCompany() {
			return company;
		}

		public void setCompany(Company company) {
			this.company = company;
		}
		
		public LocalDate getDateOfJoin() {
			return dateOfJoin;
		}

		public void setDateOfJoin(LocalDate dateOfJoin) {
			this.dateOfJoin = dateOfJoin;
		}
		
		@Override
		public String toString() {
			return "employee [employeeId=" + employeeId + ", empolyeeName=" + empolyeeName + ", company=" + company
					+ "]";
		}
		
		
}
