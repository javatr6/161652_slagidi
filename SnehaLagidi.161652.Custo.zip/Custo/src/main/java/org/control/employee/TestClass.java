package org.control.employee;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TestClass {
	
	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		
		transaction.begin();
		
		Company tcs=new Company("Tata Consultancy Service");
		Company cap=new Company("Capgemini");
		
		Employee emp1=new Employee(111,"Tom");
		emp1.setDateOfJoin(LocalDate.now());
		Employee emp2=new Employee(222,"Jerry");
		emp2.setDateOfJoin(LocalDate.now());
		Employee emp3=new Employee(333,"Ninja");
		emp3.setDateOfJoin(LocalDate.now());
		
		entityManager.persist(tcs);
		entityManager.persist(cap);
		entityManager.persist(emp1);
		entityManager.persist(emp2);
		entityManager.persist(emp2);
		
		
		
		transaction.commit();
		entityManager.close();
	}
}
