function validation(){
	
	var flag = false;
	var username = f1.username.value;
	var password = f1.password.value;
	
		
	if(username==""||username==null)
		{
		document.getElementById('uEM').innerHTML="Please enter username"
			flag=false;
		}
	else{
		if(password == ""||password == null)
			{
				document.getElementById('pEM').innerHTML="Please enter password";
					flag=false;
				document.getElementById('uEM').innerHTML=""
					flag=false;
			} 
		else
		{
			flag =true;
		}
} 
if(username.length<3)
{
	document.getElementById('uEM').innerHTML="user Name should be of minimum 3 characters"
		flag=false
}
if(password.length<3)
{
	document.getElementById('pEM').innerHTML="password must contain 3 characters";
	flag=false;
}
return flag;
} 