package org.cap.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.cap.model.LoginBean;

public class LoginDao implements ILoginDao{

	@Override
	public boolean checkUser(LoginBean loginBean) {
		String sql="select username,password from userLogin where username=? and password=?";

		try(PreparedStatement ps =getSQLConnection().prepareStatement(sql);){

			ps.setString(1, loginBean.getUserName());
			ps.setString(2, loginBean.getPassWord());
			ResultSet rs =ps.executeQuery();
		/*	if(rs.next()) {
				return true;
			}*/while(rs.next()) {
				if(rs.getString("username").equals(loginBean.getUserName())&&rs.getString("password").equals(loginBean.getPassWord()))
				return true;
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;


	}
	private Connection getSQLConnection()
	{
		Connection connection=null;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/capdatabase","root","India123");
			return connection;
		}catch(SQLException e)
		{
			e.printStackTrace();
		}catch(Exception e1) {
			e1.printStackTrace();
		}

		return connection;
	}
}

