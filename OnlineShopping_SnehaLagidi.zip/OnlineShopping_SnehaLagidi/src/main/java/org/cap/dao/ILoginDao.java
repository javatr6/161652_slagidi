package org.cap.dao;

import org.cap.model.LoginBean;

public interface ILoginDao{
	public abstract boolean checkUser(LoginBean loginBean);
}
