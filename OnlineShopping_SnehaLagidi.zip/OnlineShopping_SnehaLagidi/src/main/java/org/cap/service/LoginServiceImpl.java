package org.cap.service;

import org.cap.dao.ILoginDao;
import org.cap.dao.LoginDao;
import org.cap.model.LoginBean;

public class LoginServiceImpl implements ILoginService {
	ILoginDao loginDAO = new LoginDao();
	@Override
	public boolean checkUser(LoginBean loginBean) {
		if(loginDAO.checkUser(loginBean)) {
			return true;
		}else {
			return false;
		}
		
		
	}

}
