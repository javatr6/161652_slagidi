package org.cap.demo;

import javax.persistence.Entity;

@Entity
public class Module extends Project{
	
	public String moduleName;

	public Module() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Module(int projectId, String projectName) {
		super(projectId, projectName);
		// TODO Auto-generated constructor stub
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	@Override
	public String toString() {
		return "Module [moduleName=" + moduleName + "]";
	}
	
	
}
