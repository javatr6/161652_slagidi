package org.control.many;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class MainClass {
	
	public static void main(String[] args) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager entityManager=emf.createEntityManager();
		entityManager.getTransaction().begin();
		
		
		
		Event java=new Event();
		java.setEventId(111);
		java.setEventName("JAVA");
		
		Event dotnet=new Event();
		dotnet.setEventId(222);
		dotnet.setEventName("dotnet");
		
		Event servlet=new Event();
		servlet.setEventId(33);
		servlet.setEventName("servlet");
		
		Delegate tom=new Delegate(1,"tom");
		tom.setJoinDate(LocalDate.now());
		Delegate jerry=new Delegate(2,"jerry");
		jerry.setJoinDate(LocalDate.now());
		Delegate ninja=new Delegate(3,"ninja");
		ninja.setJoinDate(LocalDate.now());
		
		
		tom.getEvent().add(java);
		tom.getEvent().add(dotnet);
		
		jerry.getEvent().add(java);
		jerry.getEvent().add(servlet);
		
		ninja.getEvent().add(dotnet);
		ninja.getEvent().add(servlet);
		
		entityManager.persist(dotnet);
		entityManager.persist(java);
		entityManager.persist(servlet);
		entityManager.persist(tom);
		entityManager.persist(ninja);
		entityManager.persist(jerry);
		
		
		entityManager.close();
		entityManager.getTransaction().commit();
		
	}
}












