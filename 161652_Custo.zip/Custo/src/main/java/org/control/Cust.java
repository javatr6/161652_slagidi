package org.control;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Cust {
 
	@Id
	@GeneratedValue
	private int custId;
	private String firstName;
	private String lastName;
	private double regfees;
	private LocalDate joinDate;
	
	@OneToOne
	@JoinColumn(name="addressFk")
	private Address address;

	public Cust() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Cust(int custId, String firstName, String lastName, double regfees) {
		super();
		this.custId = custId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.regfees = regfees;
		this.address = address;
	}
	public Cust( String firstName, String lastName, double regfees) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.regfees = regfees;
		this.address = address;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public double getRegfees() {
		return regfees;
	}

	public void setRegfees(double regfees) {
		this.regfees = regfees;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	
	public LocalDate getJoinDate() {
		return joinDate;
	}

	public void setJoinDate(LocalDate joinDate) {
		this.joinDate = joinDate;
	}

	@Override
	public String toString() {
		return "Cust [custId=" + custId + ", firstName=" + firstName + ", lastName=" + lastName + ", regfees=" + regfees
				+ ", address=" + address + "]";
	}
	
	
	
}
