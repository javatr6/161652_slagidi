package org.control;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Address {
	
	@Id
	private int addressId;
	private String Address;
	
	@OneToOne
	@JoinColumn(name="custFK")
	private Cust CustId;

	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Address(int addressId, String address, Cust custId) {
		super();
		this.addressId = addressId;
		Address = address;
		CustId = custId;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public Cust getCustId() {
		return CustId;
	}

	public void setCustId(Cust custId) {
		CustId = custId;
	}

	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", Address=" + Address + ", CustId=" + CustId + "]";
	}
	
	
}
