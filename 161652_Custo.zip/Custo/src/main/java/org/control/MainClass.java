package org.control;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		
		transaction.begin();
		
		Cust tom=new Cust("Tom","Jerry",5000.00);
		tom.setJoinDate(LocalDate.now());
		Address address=new Address(111,"Hyderabad",tom);
		
		Cust ninja=new Cust("Ninja","Doro",5000.00);
		ninja.setJoinDate(LocalDate.now());
		Address address1=new Address(222,"Hyderabad",ninja);
		
		entityManager.persist(tom);
		entityManager.persist(ninja);
		
		transaction.commit();
		entityManager.close();
	}
}
