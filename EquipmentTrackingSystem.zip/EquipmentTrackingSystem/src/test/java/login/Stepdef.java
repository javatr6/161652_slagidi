package login;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {
	
	@Given("^User Credentials$")
	public void user_Credentials() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^Inventory personnel and tom(\\d+) are valid$")
	public void inventory_personnel_and_tom_are_valid(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Perform login$")
	public void perform_login() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^equipment auditors and jerry(\\d+) are valid$")
	public void equipment_auditors_and_jerry_are_valid(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^service personnel and ferb(\\d+) are valid$")
	public void service_personnel_and_ferb_are_valid(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^maintenance personal and xyz(\\d+) are valid$")
	public void maintenance_personal_and_xyz_are_valid(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^Equipment Tracking personnel and abc(\\d+) are valid$")
	public void equipment_Tracking_personnel_and_abc_are_valid(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}


}
